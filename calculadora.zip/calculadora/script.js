let display = document.querySelector('.display');
let historyList = document.getElementById('history-list');
let calculationsHistory = [];

function appendValue(value) {
    display.value += value;
}

function clearDisplay() {
    display.value = '';
}

function calculate() {
    try {
        let result = evaluateExpression(display.value);
        display.value = result;
        // Agregar el cálculo al historial
        calculationsHistory.unshift(display.value); // Agregar al principio
        updateHistory();
    } catch (error) {
        display.value = 'Error';
    }
}

function evaluateExpression(expression) {
    let regex = /sin|cos|tan|exp|log|sqrt|(\d+(\.\d+)?)|[+\-*/()]/g;
    let matches = expression.match(regex);
    let output = [];
    let stack = [];

    let functions = {
        'sin': Math.sin,
        'cos': Math.cos,
        'tan': Math.tan,
        'exp': Math.exp,
        'log': Math.log,
        'sqrt': Math.sqrt
    };

    let operators = {
        '+': 1,
        '-': 1,
        '*': 2,
        '/': 2,
        '(': 0
    };

    for (let token of matches) {
        if (!isNaN(token)) {
            output.push(parseFloat(token));
        } else if (token in functions) {
            stack.push(token);
        } else if (token in operators) {
            while (stack.length > 0 && operators[stack[stack.length - 1]] >= operators[token]) {
                output.push(stack.pop());
            }
            stack.push(token);
        } else if (token === '(') {
            stack.push(token);
        } else if (token === ')') {
            while (stack.length > 0 && stack[stack.length - 1] !== '(') {
                output.push(stack.pop());
            }
            stack.pop();
            if (stack.length > 0 && stack[stack.length - 1] in functions) {
                output.push(stack.pop());
            }
        }
    }

    while (stack.length > 0) {
        output.push(stack.pop());
    }

    let result = [];
    for (let token of output) {
        if (!isNaN(token)) {
            result.push(token);
        } else if (token in functions) {
            let arg = result.pop();
            result.push(functions[token](arg));
        } else {
            let b = result.pop();
            let a = result.pop();
            switch (token) {
                case '+':
                    result.push(a + b);
                    break;
                case '-':
                    result.push(a - b);
                    break;
                case '*':
                    result.push(a * b);
                    break;
                case '/':
                    result.push(a / b);
                    break;
            }
        }
    }

    return result[0];
}

function updateHistory() {
    historyList.innerHTML = '';
    calculationsHistory.forEach(calculation => {
        let li = document.createElement('li');
        li.textContent = calculation;
        historyList.appendChild(li);
    });
}

function sinFunction() {
    display.value = Math.sin(parseFloat(display.value));
}

function cosFunction() {
    display.value = Math.cos(parseFloat(display.value));
}

function tanFunction() {
    display.value = Math.tan(parseFloat(display.value));
}

function expFunction() {
    display.value = Math.exp(parseFloat(display.value));
}

function logFunction() {
    display.value = Math.log(parseFloat(display.value));
}

function powerFunction() {
    display.value = Math.pow(parseFloat(display.value), 2);
}

function sqrtFunction() {
    display.value = Math.sqrt(parseFloat(display.value));
}

function factorialFunction() {
    let result = 1;
    for (let i = 1; i <= parseFloat(display.value); i++) {
        result *= i;
    }
    display.value = result;
}

function toggleTheme() {
    document.body.classList.toggle('dark-theme');
}
